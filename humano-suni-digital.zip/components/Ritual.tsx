
import React, { useState } from 'react';

const Ritual: React.FC = () => {
  const [step, setStep] = useState(0);
  const [completed, setCompleted] = useState(false);

  const questions = [
    { q: "Qual foi a melhor decisão que você tomou hoje?", a: "" },
    { q: "O que você sentiu quando seu plano não saiu como o esperado?", a: "" },
    { q: "Se você tivesse que descrever sua energia agora em uma palavra, qual seria?", a: "" }
  ];

  const handleNext = () => {
    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setCompleted(true);
    }
  };

  if (completed) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-6 fade-in">
        <div className="w-20 h-20 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/30 aura-glow">
          <i className="fa-solid fa-check text-blue-400 text-3xl"></i>
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-serif font-bold text-white">Ritual Concluído</h2>
          <p className="text-zinc-400 max-w-sm mx-auto">Sua consciência foi registrada. Hoje você deu mais um passo em direção à sua versão mais presente.</p>
        </div>
        <button 
          onClick={() => setCompleted(false)}
          className="px-8 py-3 bg-white text-black rounded-full font-bold hover:bg-zinc-200 transition-colors"
        >
          Voltar amanhã
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-12 fade-in">
      <div className="space-y-2">
        <span className="text-xs font-bold text-blue-400 uppercase tracking-[0.2em]">Check-in do Crepúsculo</span>
        <h2 className="text-4xl font-serif font-bold text-white">Momento de Silêncio</h2>
      </div>

      <div className="max-w-xl w-full space-y-8">
        <div className="space-y-4">
          <p className="text-xl text-zinc-300 font-light italic leading-relaxed">"{questions[step].q}"</p>
          <textarea 
            placeholder="Apenas deixe as palavras fluírem..."
            className="w-full h-32 bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 text-white outline-none focus:border-blue-500/50 transition-all resize-none"
          ></textarea>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {questions.map((_, idx) => (
              <div key={idx} className={`w-12 h-1 rounded-full ${idx <= step ? 'bg-blue-500' : 'bg-zinc-800'}`}></div>
            ))}
          </div>
          <button 
            onClick={handleNext}
            className="flex items-center gap-2 text-white hover:text-blue-400 transition-colors"
          >
            {step === questions.length - 1 ? 'Finalizar' : 'Próxima reflexão'}
            <i className="fa-solid fa-arrow-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Ritual;
