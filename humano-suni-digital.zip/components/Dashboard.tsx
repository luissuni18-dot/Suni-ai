
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { LifeStats } from '../types';

interface DashboardProps {
  stats: LifeStats;
}

const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
  const data = [
    { subject: 'Clareza', A: stats.clareza, fullMark: 100 },
    { subject: 'Foco', A: stats.foco, fullMark: 100 },
    { subject: 'Disciplina', A: stats.disciplina, fullMark: 100 },
    { subject: 'Energia', A: stats.energia, fullMark: 100 },
    { subject: 'Bem-estar', A: stats.bemEstar, fullMark: 100 },
    { subject: 'Coragem', A: stats.coragem, fullMark: 100 },
  ];

  const getLevelInfo = (val: number) => {
    if (val < 30) return { label: 'Incipiente', color: 'text-red-400' };
    if (val < 60) return { label: 'Em Construção', color: 'text-yellow-400' };
    if (val < 85) return { label: 'Consistente', color: 'text-green-400' };
    return { label: 'Maestria', color: 'text-blue-400' };
  };

  return (
    <div className="p-8 md:p-12 space-y-12 overflow-y-auto h-full custom-scrollbar">
      <div className="max-w-4xl mx-auto space-y-2">
        <h2 className="text-3xl font-serif font-bold text-white">Painel de Vida</h2>
        <p className="text-zinc-400">Suas métricas humanas não são pontos em um jogo, são níveis de consciência.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
        <div className="h-[400px] bg-zinc-900/30 rounded-3xl border border-zinc-800 p-6 flex items-center justify-center aura-glow">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
              <PolarGrid stroke="#27272a" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#71717a', fontSize: 12 }} />
              <Radar
                name="Você"
                dataKey="A"
                stroke="#3b82f6"
                fill="#3b82f6"
                fillOpacity={0.4}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {data.map((item) => {
            const info = getLevelInfo(item.A);
            return (
              <div key={item.subject} className="bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800/50 space-y-3">
                <span className="text-xs text-zinc-500 uppercase tracking-widest font-semibold">{item.subject}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-white">{item.A}</span>
                  <span className="text-xs text-zinc-500">/ 100</span>
                </div>
                <p className={`text-xs font-medium ${info.color}`}>{info.label}</p>
                <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full transition-all duration-1000" style={{ width: `${item.A}%` }}></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="max-w-4xl mx-auto bg-blue-500/5 border border-blue-500/20 rounded-2xl p-8 space-y-4">
        <h3 className="font-serif text-xl font-bold text-blue-300">Análise da Consciência</h3>
        <p className="text-zinc-300 leading-relaxed italic">
          "Notei que sua Coragem aumentou após a conversa sobre a transição de carreira, mas seu Foco parece diluído. O que está drenando sua atenção ultimamente?"
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
