
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

const LiveSession: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const sessionRef = useRef<any>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>(0);

  // Standard Base64 Decode
  function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  // Standard PCM Audio Decode
  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function createBlob(data: Float32Array) {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  }

  const drawVisualizer = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const time = Date.now() * 0.002;
      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#3b82f6';

      for (let x = 0; x < canvas.width; x++) {
        const y = Math.sin(x * 0.05 + time) * 15 * Math.sin(x * 0.01 + time * 0.5) + canvas.height / 2;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      animationFrameRef.current = requestAnimationFrame(render);
    };
    render();
  };

  const startSession = async () => {
    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            drawVisualizer();
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
              const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64EncodedAudioString = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64EncodedAudioString && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(decode(base64EncodedAudioString), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
              });

              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current = nextStartTimeRef.current + audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              for (const source of sourcesRef.current.values()) {
                source.stop();
                sourcesRef.current.delete(source);
              }
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => { 
            setIsActive(false); 
            setIsConnecting(false); 
            cancelAnimationFrame(animationFrameRef.current);
          },
          onerror: (e) => { 
            console.error('Session error:', e); 
            setIsActive(false); 
            setIsConnecting(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          systemInstruction: "Você é Suní, uma presença consciente e Mental Coach. Fale com naturalidade, seja breve e foque na evolução humana."
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
      alert("Não foi possível acessar o microfone ou a API. Verifique suas permissões.");
    }
  };

  const stopSession = () => {
    sessionRef.current?.close();
    setIsActive(false);
    cancelAnimationFrame(animationFrameRef.current);
    if (inputAudioContextRef.current) inputAudioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-8 text-center relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.05)_0%,transparent_70%)]"></div>
      
      {!isActive ? (
        <div className="space-y-12 fade-in relative z-10">
          <div className="w-40 h-40 rounded-full border border-zinc-800 flex items-center justify-center mx-auto relative group cursor-pointer" onClick={startSession}>
            <div className={`absolute inset-0 rounded-full bg-blue-500/10 blur-2xl transition-all ${isConnecting ? 'animate-pulse' : 'group-hover:bg-blue-500/20'}`}></div>
            <div className="w-24 h-24 rounded-full border border-blue-500/30 flex items-center justify-center bg-zinc-900 group-hover:border-blue-500 transition-all">
               <i className={`fa-solid fa-microphone text-4xl transition-colors ${isConnecting ? 'text-blue-400 animate-pulse' : 'text-zinc-600 group-hover:text-blue-400'}`}></i>
            </div>
          </div>
          <div className="space-y-3">
            <h2 className="text-4xl font-serif font-bold text-white tracking-tight">{isConnecting ? 'Estabelecendo Frequência...' : 'Sessão Viva'}</h2>
            <p className="text-zinc-500 max-w-sm mx-auto font-light leading-relaxed">
              O Diálogo Puro. Sem telas, sem teclados. Apenas a sua voz e a presença consciente de Suní.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-16 fade-in relative z-10 w-full max-w-xl">
          <div className="relative h-32 flex items-center justify-center">
            <canvas ref={canvasRef} width={400} height={100} className="w-full h-full" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0c] via-transparent to-[#0a0a0c]"></div>
          </div>
          
          <div className="space-y-4">
             <div className="flex justify-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></span>
                <span className="text-[10px] font-bold text-blue-500 uppercase tracking-[0.4em]">Sintonizado com você</span>
             </div>
             <p className="text-zinc-400 font-serif italic text-lg">Suní está ouvindo a sua essência...</p>
          </div>

          <button onClick={stopSession} className="px-10 py-4 bg-zinc-900 text-zinc-300 rounded-full hover:bg-red-500/20 hover:text-red-400 transition-all border border-zinc-800 font-bold uppercase tracking-widest text-xs">
            Encerrar Conexão
          </button>
        </div>
      )}
    </div>
  );
};

export default LiveSession;
