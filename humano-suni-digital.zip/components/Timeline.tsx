
import React from 'react';
import { LifeEvent } from '../types';

interface TimelineProps {
  events: LifeEvent[];
}

const Timeline: React.FC<TimelineProps> = ({ events }) => {
  return (
    <div className="p-8 md:p-12 overflow-y-auto h-full custom-scrollbar">
      <div className="max-w-2xl mx-auto mb-16 space-y-2">
        <h2 className="text-3xl font-serif font-bold text-white">Linha do Tempo da Vida</h2>
        <p className="text-zinc-400">Uma biografia viva, construída através dos nossos encontros e das suas escolhas.</p>
      </div>

      <div className="max-w-2xl mx-auto relative space-y-12">
        <div className="absolute left-[11px] top-4 bottom-4 w-px bg-zinc-800"></div>
        
        {events.map((event, idx) => (
          <div key={event.id} className="relative pl-10 animate-in fade-in" style={{ animationDelay: `${idx * 150}ms` }}>
            <div className={`absolute left-0 top-2 w-6 h-6 rounded-full border-4 border-[#0a0a0c] z-10 ${
              event.emotion === 'positive' ? 'bg-green-500' : event.emotion === 'challenging' ? 'bg-amber-500' : 'bg-zinc-500'
            }`}></div>
            
            <div className="space-y-1">
              <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest">{event.month} {event.year}</span>
              <h3 className="text-xl font-serif font-bold text-white">{event.title}</h3>
              <p className="text-zinc-400 leading-relaxed text-sm md:text-base">{event.description}</p>
              
              <div className="mt-4 flex gap-2">
                <span className="px-2 py-1 rounded-md bg-zinc-900 text-[10px] text-zinc-500 border border-zinc-800">Marco Histórico</span>
                {event.emotion === 'challenging' && (
                  <span className="px-2 py-1 rounded-md bg-amber-500/10 text-[10px] text-amber-500 border border-amber-500/20">Crescimento sob Pressão</span>
                )}
              </div>
            </div>
          </div>
        ))}

        <div className="relative pl-10 opacity-40">
           <div className="absolute left-0 top-2 w-6 h-6 rounded-full border-4 border-[#0a0a0c] z-10 bg-zinc-800 animate-pulse"></div>
           <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-600 uppercase tracking-widest">O Futuro</span>
              <h3 className="text-xl font-serif font-bold text-zinc-600">Escrevendo agora...</h3>
              <p className="text-zinc-700 leading-relaxed text-sm italic">Onde suas decisões de hoje nos levarão amanhã?</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;
