
import React, { useState, useEffect } from 'react';
import { geminiService } from '../services/gemini';

const CreativeLab: React.FC = () => {
  const [activeTool, setActiveTool] = useState<'gen-img' | 'edit-img' | 'gen-vid'>('gen-img');
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [videoAspectRatio, setVideoAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [imageSize, setImageSize] = useState('1K');
  const [baseImage, setBaseImage] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if ((window as any).aistudio?.hasSelectedApiKey) {
        const selected = await (window as any).aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } else {
        setHasKey(true); // Fallback for environments where key is injected
      }
    };
    checkKey();
  }, []);

  const handleRun = async () => {
    if (!prompt.trim() && !baseImage) return;

    // Check if key is required for Veo/Pro and prompt user if not selected
    if ((activeTool === 'gen-vid' || imageSize === '2K' || imageSize === '4K') && !hasKey) {
       if ((window as any).aistudio?.openSelectKey) {
          await (window as any).aistudio.openSelectKey();
          setHasKey(true);
       }
    }

    setIsLoading(true);
    setResult(null);

    try {
      let res = '';
      if (activeTool === 'gen-img') {
        res = await geminiService.generateImage(prompt, aspectRatio, imageSize);
      } else if (activeTool === 'edit-img' && baseImage) {
        // Fix for missing editImage method
        res = await geminiService.editImage(prompt, baseImage);
      } else if (activeTool === 'gen-vid') {
        res = await geminiService.generateVideo(prompt, videoAspectRatio, baseImage || undefined);
      }
      setResult(res);
    } catch (e: any) {
      console.error(e);
      if (e.message?.includes("Requested entity was not found.")) {
         alert("Erro na chave da API Studio. Por favor, selecione uma chave de um projeto com faturamento ativo.");
         if ((window as any).aistudio?.openSelectKey) await (window as any).aistudio.openSelectKey();
      } else {
         alert("A criação encontrou um obstáculo. Talvez a visão precise ser redefinida.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setBaseImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-8 md:p-12 h-full flex flex-col custom-scrollbar overflow-y-auto">
      <div className="max-w-4xl mx-auto w-full mb-12">
        <h2 className="text-3xl font-serif font-bold text-white mb-2">Laboratório de Manifestação</h2>
        <p className="text-zinc-500">Transforme intenção em realidade visual através da inteligência profunda.</p>
        {!hasKey && (window as any).aistudio && (
          <div className="mt-4 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
            <p className="text-xs text-amber-500 mb-2">Usuários Veo/Pro: É necessário selecionar uma chave de API com faturamento ativo.</p>
            <button 
              onClick={() => (window as any).aistudio.openSelectKey()} 
              className="text-[10px] bg-amber-500 text-black px-4 py-2 rounded-lg font-bold uppercase tracking-widest"
            >
              Configurar Chave <i className="fa-solid fa-key ml-1"></i>
            </button>
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="block mt-2 text-[10px] text-zinc-500 underline">Documentação de Faturamento</a>
          </div>
        )}
      </div>

      <div className="max-w-6xl mx-auto w-full grid grid-cols-1 lg:grid-cols-3 gap-8 mb-32">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-1 flex">
            {['gen-img', 'edit-img', 'gen-vid'].map((tool) => (
              <button
                key={tool}
                onClick={() => { setActiveTool(tool as any); setResult(null); }}
                className={`flex-1 py-2 text-[10px] font-bold uppercase rounded-xl transition-all ${
                  activeTool === tool ? 'bg-zinc-800 text-white' : 'text-zinc-600 hover:text-zinc-400'
                }`}
              >
                {tool === 'gen-img' ? 'Imagem' : tool === 'edit-img' ? 'Editar' : 'Veo Vídeo'}
              </button>
            ))}
          </div>

          <div className="space-y-4 bg-zinc-900/30 p-6 rounded-2xl border border-zinc-800">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Descreva sua visão..."
              className="w-full h-32 bg-transparent text-sm border-none outline-none resize-none text-white focus:ring-1 focus:ring-blue-500/20 rounded-lg p-2"
            />
            
            {(activeTool === 'edit-img' || activeTool === 'gen-vid') && (
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">Referência Visual</span>
                <input type="file" onChange={handleFile} className="block w-full text-xs text-zinc-500" accept="image/*" />
                {baseImage && <div className="relative group"><img src={baseImage} className="w-full h-32 object-cover rounded-lg border border-zinc-700" /><button onClick={() => setBaseImage(null)} className="absolute top-1 right-1 bg-black/50 p-1 rounded-full text-xs opacity-0 group-hover:opacity-100 transition-opacity"><i className="fa-solid fa-xmark"></i></button></div>}
              </div>
            )}

            {activeTool === 'gen-img' && (
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-zinc-500 uppercase">Aspecto da Imagem</span>
                  <div className="grid grid-cols-4 gap-2">
                    {['1:1', '3:4', '4:3', '9:16', '16:9'].map(r => (
                      <button key={r} onClick={() => setAspectRatio(r)} className={`text-[10px] p-2 rounded border ${aspectRatio === r ? 'bg-blue-500 border-blue-400' : 'bg-zinc-800 border-zinc-700'}`}>{r}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-zinc-500 uppercase">Resolução (Pro)</span>
                  <select value={imageSize} onChange={(e) => setImageSize(e.target.value)} className="w-full bg-zinc-800 text-xs p-2 rounded-lg text-white">
                    {['1K', '2K', '4K'].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            )}

            {activeTool === 'gen-vid' && (
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">Aspecto do Vídeo (Veo)</span>
                <div className="flex gap-2">
                  <button onClick={() => setVideoAspectRatio('16:9')} className={`flex-1 py-2 rounded border text-xs ${videoAspectRatio === '16:9' ? 'bg-blue-500 border-blue-400' : 'bg-zinc-800 border-zinc-700'}`}>16:9 (Landscape)</button>
                  <button onClick={() => setVideoAspectRatio('9:16')} className={`flex-1 py-2 rounded border text-xs ${videoAspectRatio === '9:16' ? 'bg-blue-500 border-blue-400' : 'bg-zinc-800 border-zinc-700'}`}>9:16 (Portrait)</button>
                </div>
              </div>
            )}

            <button
              onClick={handleRun}
              disabled={isLoading}
              className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-500 transition-all aura-glow disabled:opacity-50"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                   <i className="fa-solid fa-spinner animate-spin"></i>
                   Processando átomos...
                </span>
              ) : 'Manifestar Agora'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 min-h-[500px] bg-zinc-900/10 border border-dashed border-zinc-800 rounded-3xl flex items-center justify-center p-4 relative overflow-hidden">
          {isLoading ? (
            <div className="text-center space-y-4 z-10">
              <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-zinc-500 animate-pulse text-sm font-serif italic">"A paciência é o berço da criação..."</p>
            </div>
          ) : result ? (
            activeTool === 'gen-vid' ? (
              <video src={result} controls className="max-w-full max-h-full rounded-2xl shadow-2xl" autoPlay loop />
            ) : (
              <div className="relative group max-w-full max-h-full">
                <img src={result} className="rounded-2xl shadow-2xl" />
                <a href={result} download="manifestation.png" className="absolute bottom-4 right-4 bg-black/60 p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-500">
                  <i className="fa-solid fa-download"></i>
                </a>
              </div>
            )
          ) : (
            <div className="text-center text-zinc-700 space-y-4 opacity-40">
              <i className="fa-solid fa-wand-magic-sparkles text-6xl"></i>
              <p className="text-sm font-serif italic">Sua visão está aguardando sua primeira intenção.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreativeLab;
