
import React, { useState, useRef, useEffect } from 'react';
import { Message, Language } from '../types.ts';
import { geminiService } from '../services/gemini.ts';

interface ChatProps {
  messages: Message[];
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  context: string;
  language: Language;
}

const Chat: React.FC<ChatProps> = ({ messages, setMessages, context, language }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [isLiteMode, setIsLiteMode] = useState(false);
  const [grounding, setGrounding] = useState<'none' | 'search' | 'maps'>('none');
  const [attachment, setAttachment] = useState<{ name: string, data: string, type: string } | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setAttachment({ 
          name: file.name, 
          data: ev.target?.result as string, 
          type: file.type 
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !attachment) || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      type: attachment ? (attachment.type.startsWith('image') ? 'image' : 'video') : 'text',
      dataUrl: attachment?.data
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setAttachment(null);
    setIsLoading(true);

    const botMsgId = (Date.now() + 1).toString();
    const botMsg: Message = {
      id: botMsgId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
    };
    
    setMessages(prev => [...prev, botMsg]);

    try {
      let accumulated = '';
      await geminiService.streamChat(
        userMsg.content, 
        context, 
        (chunk) => {
          accumulated += chunk;
          setMessages(prev => 
            prev.map(m => m.id === botMsgId ? { ...m, content: accumulated } : m)
          );
        },
        {
          lang: language,
          mode: isLiteMode ? 'lite' : 'pro',
          deepThinking: isThinkingMode,
          grounding: grounding === 'none' ? undefined : grounding,
          attachment: userMsg.dataUrl ? { mimeType: userMsg.type === 'image' ? 'image/png' : 'video/mp4', data: userMsg.dataUrl } : undefined
        }
      );
    } catch (error) {
      console.error(error);
      setMessages(prev => 
        prev.map(m => m.id === botMsgId ? { ...m, content: "Erro na conexão. Suní detectou uma falha na rede. Vamos tentar de novo?" } : m)
      );
    } finally {
      setIsLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64 = (reader.result as string).split(',')[1];
          const text = await geminiService.transcribeAudio(base64);
          setInput(text);
        };
        reader.readAsDataURL(blob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Recording failed", err);
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const playTTS = async (text: string) => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const base64 = await geminiService.generateTTS(text);
      if (base64) {
        // Standard decoding logic for raw PCM as per guidelines
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
        
        const dataInt16 = new Int16Array(bytes.buffer);
        const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < dataInt16.length; i++) {
          channelData[i] = dataInt16[i] / 32768.0;
        }
        
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (e) { console.error("TTS failed", e); }
  };

  return (
    <div className="flex flex-col h-full relative">
      <div className="absolute top-0 left-0 right-0 z-10 px-6 py-2 flex justify-center flex-wrap gap-2 bg-gradient-to-b from-[#0a0a0c] to-transparent">
        <button 
          onClick={() => setIsThinkingMode(!isThinkingMode)}
          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all flex items-center gap-2 ${
            isThinkingMode ? 'bg-blue-500 text-white aura-glow' : 'bg-zinc-800 text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <i className="fa-solid fa-brain"></i> Pro + Reflexão
        </button>
        <button 
          onClick={() => setIsLiteMode(!isLiteMode)}
          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all flex items-center gap-2 ${
            isLiteMode ? 'bg-cyan-500 text-white aura-glow' : 'bg-zinc-800 text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <i className="fa-solid fa-bolt"></i> Resposta Instantânea
        </button>
        <button 
          onClick={() => setGrounding(grounding === 'search' ? 'none' : 'search')}
          className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all flex items-center gap-2 ${
            grounding === 'search' ? 'bg-orange-500 text-white aura-glow' : 'bg-zinc-800 text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <i className="fa-solid fa-earth-americas"></i> Google Search
        </button>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 md:p-12 space-y-10 custom-scrollbar pb-44 pt-20"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 fade-in">
            <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center aura-glow mb-4">
              <i className="fa-solid fa-bolt-lightning text-blue-400 text-2xl"></i>
            </div>
            <h2 className="text-3xl font-serif font-bold text-white tracking-tight">Pronto para a Performance?</h2>
            <p className="max-w-md text-zinc-500 leading-relaxed font-light">
              Sou Suní, sua Mental Coach. Vamos analisar seus padrões e acelerar sua evolução. O que impede seu foco hoje?
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in`}>
            <div className={`max-w-[85%] md:max-w-[70%] space-y-2 flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className="flex items-start gap-2 group">
                {msg.role === 'model' && (
                  <button onClick={() => playTTS(msg.content)} className="opacity-0 group-hover:opacity-100 transition-opacity p-2 text-zinc-500 hover:text-white">
                    <i className="fa-solid fa-volume-high"></i>
                  </button>
                )}
                <div className={`px-5 py-4 rounded-2xl text-sm md:text-base leading-relaxed ${
                  msg.role === 'user' ? 'bg-zinc-800 text-white rounded-br-none' : 'bg-zinc-900/40 border border-zinc-800 text-zinc-200 rounded-bl-none'
                }`}>
                  {msg.content || (isLoading && <div className="flex gap-1 animate-pulse italic">Analisando...</div>)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 bg-gradient-to-t from-[#0a0a0c] via-[#0a0a0c] to-transparent">
        <div className="max-w-4xl mx-auto flex items-center gap-3 bg-zinc-900/80 border border-zinc-800 rounded-2xl p-2 pl-4 focus-within:border-blue-500/50 transition-all aura-glow">
          <button 
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onMouseLeave={stopRecording}
            className={`p-3 transition-colors ${isRecording ? 'text-red-500 animate-pulse' : 'text-zinc-500 hover:text-blue-400'}`}
          >
            <i className="fa-solid fa-microphone"></i>
          </button>
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Relate seu desafio..."
            className="flex-1 bg-transparent border-none outline-none text-white text-sm py-3"
          />
          <button onClick={handleSend} disabled={(!input.trim() && !attachment) || isLoading} className="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center hover:bg-blue-400 transition-all disabled:opacity-50 shadow-lg">
            <i className="fa-solid fa-arrow-up"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
