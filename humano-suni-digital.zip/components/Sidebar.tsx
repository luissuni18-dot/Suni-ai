
import React from 'react';
import { AppView, Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface SidebarProps {
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, language, setLanguage }) => {
  const t = TRANSLATIONS[language];
  
  const navItems = [
    { id: AppView.CHAT, icon: 'fa-comment-dots', label: t.dialogue },
    { id: AppView.EXISTENTIAL, icon: 'fa-compass', label: t.counselor },
    { id: AppView.LIVE, icon: 'fa-microphone-lines', label: t.live },
    { id: AppView.CREATIVE, icon: 'fa-wand-magic-sparkles', label: t.creative },
    { id: AppView.TIMELINE, icon: 'fa-timeline', label: t.timeline },
    { id: AppView.DASHBOARD, icon: 'fa-chart-line', label: t.evolution },
    { id: AppView.RITUAL, icon: 'fa-sun', label: t.ritual },
  ];

  return (
    <div className="w-20 md:w-64 bg-[#0d0d0f] border-r border-zinc-800 flex flex-col h-full transition-all duration-300">
      <div className="p-6 flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-500 aura-glow flex items-center justify-center">
            <i className="fa-solid fa-sun text-white text-sm"></i>
          </div>
          <span className="hidden md:block font-serif font-bold text-xl tracking-tight text-white">Suní</span>
        </div>
        
        <div className="hidden md:flex gap-2 p-1 bg-zinc-900 rounded-lg">
          {(['pt', 'en', 'es'] as Language[]).map((lang) => (
            <button
              key={lang}
              onClick={() => setLanguage(lang)}
              className={`flex-1 text-[10px] font-bold py-1 rounded transition-all ${
                language === lang ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-600 hover:text-zinc-400'
              }`}
            >
              {lang.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              activeView === item.id 
                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' 
                : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50'
            }`}
          >
            <i className={`fa-solid ${item.icon} w-6 text-center text-lg`}></i>
            <span className="hidden md:block font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-zinc-800/50">
        <button 
          onClick={() => setActiveView(AppView.IDENTITY)}
          className={`w-full hidden md:flex items-center gap-3 p-3 rounded-xl transition-all ${
            activeView === AppView.IDENTITY ? 'bg-zinc-800' : 'bg-zinc-900/50 hover:bg-zinc-800'
          }`}
        >
          <img src="https://picsum.photos/id/64/100/100" className="w-10 h-10 rounded-full grayscale" alt="User" />
          <div className="flex-1 overflow-hidden text-left">
            <p className="text-sm font-semibold truncate text-white">{t.aura}</p>
            <p className="text-xs text-zinc-500 truncate">Vigilante Consciente</p>
          </div>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
