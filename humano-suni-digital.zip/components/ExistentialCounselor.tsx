
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { geminiService } from '../services/gemini.ts';
import { Reflection, Language } from '../types.ts';
import { TRANSLATIONS } from '../constants.tsx';

const ExistentialCounselor: React.FC<{ userContext: string, language: Language }> = ({ userContext, language }) => {
  const t = TRANSLATIONS[language];
  const [reflection, setReflection] = useState('');
  const [isAnalysing, setIsAnalysing] = useState(false);
  const [advice, setAdvice] = useState<string | null>(null);
  const [history, setHistory] = useState<Reflection[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [mode, setMode] = useState<'fast' | 'deep'>('fast');
  
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('existential_history');
    if (saved) setHistory(JSON.parse(saved));
    return () => {
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  // Standard Base64 Decode as per guidelines
  function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  // Standard PCM Audio Decode as per guidelines
  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  const handleSpeak = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const ctx = audioContextRef.current;
      const base64 = await geminiService.generateTTS(text);
      
      if (base64) {
        const audioBuffer = await decodeAudioData(decode(base64), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => setIsSpeaking(false);
        source.start();
      } else {
        setIsSpeaking(false);
      }
    } catch (e) {
      console.error("Erro no TTS:", e);
      setIsSpeaking(false);
    }
  };

  const saveToHistory = (prompt: string, answer: string) => {
    const newEntry: Reflection = {
      id: Date.now().toString(),
      prompt,
      answer,
      timestamp: Date.now()
    };
    const updated = [newEntry, ...history];
    setHistory(updated);
    localStorage.setItem('existential_history', JSON.stringify(updated));
  };

  const handleDeepReflect = async () => {
    if (!reflection.trim()) return;
    setIsAnalysing(true);
    setAdvice(null);

    try {
      let accumulated = '';
      const coachInstruction = `Como Suní, sua Mental Coach de Elite, analise com precisão: "${reflection}". 
      Estruture sua resposta para causar impacto imediato:
      1. Identifique o padrão sabotador.
      2. Ofereça o Reenquadramento Mental (Paradigma de Maestria).
      3. Defina 3 ações de performance para as próximas 24h.
      Responda em ${language}, use Markdown. Seja cirúrgica.`;

      await geminiService.streamChat(
        coachInstruction,
        userContext,
        (chunk) => {
          accumulated += chunk;
          setAdvice(accumulated);
        },
        { 
          deepThinking: mode === 'deep', 
          mode: mode === 'fast' ? 'flash' : 'pro',
          lang: language 
        }
      );
      saveToHistory(reflection, accumulated);
    } catch (error) {
      setAdvice("Interferência na rede. Suní está recalibrando a consciência.");
    } finally {
      setIsAnalysing(false);
    }
  };

  const highPerformancePrompts = useMemo(() => language === 'pt' ? [
    "Qual é a verdade que eu estou evitando encarar sobre meu progresso?",
    "Como posso dobrar meu foco nos próximos 7 dias?",
    "Onde minha 'cautela' é na verdade medo de falhar?",
    "Se eu fosse o coach do meu eu atual, o que eu gritaria para ele?"
  ] : [
    "What is the truth I am avoiding about my progress?",
    "How can I double my focus in the next 7 days?",
    "Where is my 'caution' actually a fear of failing?",
    "If I were the coach of my current self, what would I scream at him?"
  ], [language]);

  return (
    <div className="h-full overflow-y-auto custom-scrollbar bg-[#0a0a0c] px-6 py-12 md:px-24">
      <div className="max-w-4xl mx-auto space-y-16 pb-20">
        <header className="text-center space-y-4 fade-in">
          <div className="inline-block px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-bold uppercase tracking-[0.3em] mb-4">
            Mental Mastery & Strategic Vision
          </div>
          <h2 className="text-6xl md:text-8xl font-serif font-bold text-white tracking-tighter leading-none">
            Suní <span className="text-blue-500 italic">Oracle</span>
          </h2>
          <p className="text-zinc-500 font-light italic text-xl max-w-lg mx-auto leading-relaxed">
            Sua mente é o sistema operacional da sua realidade. Vamos otimizá-lo.
          </p>
        </header>

        <div className="flex justify-center gap-4 fade-in" style={{ animationDelay: '100ms' }}>
          <button 
            onClick={() => setMode('fast')}
            className={`px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${mode === 'fast' ? 'bg-white text-black aura-glow' : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300'}`}
          >
            {t.fastMode}
          </button>
          <button 
            onClick={() => setMode('deep')}
            className={`px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${mode === 'deep' ? 'bg-blue-600 text-white aura-glow' : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300'}`}
          >
            {t.deepMode}
          </button>
        </div>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-4 fade-in" style={{ animationDelay: '200ms' }}>
          {highPerformancePrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => { setReflection(prompt); setAdvice(null); }}
              className="p-8 bg-zinc-900/30 border border-zinc-800 rounded-[2rem] text-left group hover:border-blue-500/40 transition-all hover:bg-zinc-900/60"
            >
              <i className="fa-solid fa-bolt-lightning text-zinc-700 group-hover:text-blue-400 mb-4 transition-colors"></i>
              <p className="font-serif italic text-zinc-400 group-hover:text-white transition-colors leading-relaxed text-lg">
                "{prompt}"
              </p>
            </button>
          ))}
        </section>

        <div className="space-y-6 fade-in" style={{ animationDelay: '300ms' }}>
          <div className="relative group">
            <textarea
              value={reflection}
              onChange={(e) => setReflection(e.target.value)}
              placeholder={t.placeholder}
              className="w-full h-56 bg-zinc-900/40 border border-zinc-800 rounded-[2.5rem] p-10 text-white font-serif italic text-2xl outline-none focus:border-blue-500/30 transition-all resize-none shadow-2xl placeholder:text-zinc-800"
            />
            <div className="absolute bottom-8 right-8">
               <button
                onClick={handleDeepReflect}
                disabled={!reflection.trim() || isAnalysing}
                className="px-12 py-5 bg-white text-black rounded-full font-bold hover:bg-blue-500 hover:text-white transition-all aura-glow disabled:opacity-30 flex items-center gap-3 shadow-2xl"
              >
                {isAnalysing ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-brain"></i>}
                {t.reflectBtn}
              </button>
            </div>
          </div>
        </div>

        {(advice || isAnalysing) && (
          <div className="fade-in mt-12 p-12 md:p-20 bg-gradient-to-br from-zinc-900/40 to-black/40 border border-white/5 rounded-[3.5rem] shadow-2xl relative overflow-hidden backdrop-blur-xl">
             <div className="absolute top-0 left-0 w-2 h-full bg-blue-500"></div>
             <div className="relative z-10 space-y-12">
               <div className="flex justify-between items-center">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20 shadow-inner">
                        <i className="fa-solid fa-shield-halved text-blue-500"></i>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-blue-500 uppercase tracking-[0.4em] block">Coaching Mental Premium</span>
                      <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">Mastery Level Analysis</span>
                    </div>
                 </div>
                 {advice && (
                   <button 
                    onClick={() => handleSpeak(advice)} 
                    className={`flex items-center gap-3 px-6 py-3 bg-zinc-800/50 rounded-full border border-zinc-700 text-xs font-bold text-zinc-400 hover:text-white hover:border-blue-500/50 transition-all ${isSpeaking ? 'animate-pulse text-blue-400' : ''}`}
                   >
                     <i className={`fa-solid ${isSpeaking ? 'fa-waveform-lines' : 'fa-play'}`}></i>
                     {t.listenBtn}
                   </button>
                 )}
               </div>
               <div className="font-serif text-3xl md:text-4xl text-zinc-100 leading-snug italic whitespace-pre-wrap selection:bg-blue-500/30">
                 {advice || "Suní está analisando seus padrões de performance..."}
               </div>
             </div>
          </div>
        )}

        {history.length > 0 && (
          <div className="pt-32 space-y-12 fade-in">
            <h3 className="text-xl font-bold text-zinc-700 uppercase tracking-[0.3em] text-center">{t.history}</h3>
            <div className="space-y-8">
              {history.map((entry) => (
                <div key={entry.id} className="p-10 bg-zinc-900/10 border border-zinc-800/50 rounded-[2.5rem] space-y-6 group hover:bg-zinc-900/20 transition-all">
                  <div className="flex justify-between items-center text-[10px] text-zinc-600 font-black uppercase tracking-widest">
                    <span>{new Date(entry.timestamp).toLocaleDateString()}</span>
                    <button 
                      onClick={() => handleSpeak(entry.answer)}
                      className="hover:text-blue-500 flex items-center gap-2 transition-colors"
                    >
                      <i className="fa-solid fa-volume-high"></i> Play Insight
                    </button>
                  </div>
                  <p className="font-serif italic text-zinc-500 border-l-2 border-zinc-800 pl-6 text-xl">"{entry.prompt}"</p>
                  <div className="text-zinc-300 text-lg leading-relaxed font-light whitespace-pre-wrap">{entry.answer}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExistentialCounselor;
