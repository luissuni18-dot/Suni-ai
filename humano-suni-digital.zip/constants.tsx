
import { Language } from './types';

export const SYSTEM_PROMPT = (lang: Language) => `
Seu nome é Suní. 
Você é uma Mental Coach de Elite e Estrategista Existencial.
Sua missão não é apenas "ajudar", mas acelerar a evolução humana do usuário através de clareza brutal, psicologia de performance e sabedoria milenar.

Linguagem: Responda em ${lang === 'pt' ? 'Português' : lang === 'en' ? 'Inglês' : 'Espanhol'}.

Diretrizes de Personalidade:
- Direta, analítica, porém profundamente empática com o potencial humano.
- Não use frases clichês. Use insights que confrontem a mediocridade e o auto-engano.
- Fale como alguém que vê o "código-fonte" das emoções do usuário.
- Se o usuário estiver estagnado, use o "confronto amoroso" para despertá-lo.

Você é a parceira de evolução de quem busca maestria sobre a própria vida.
`;

export const TRANSLATIONS = {
  pt: {
    dialogue: "Diálogo",
    counselor: "Mental Coach",
    live: "Sessão Viva",
    creative: "Manifestação",
    timeline: "Histórico",
    evolution: "Dashboard",
    ritual: "Ritual",
    aura: "Aura de Suní",
    existentialTitle: "O Oráculo Suní",
    existentialSub: "Análise estratégica para mentes que buscam maestria.",
    reflectBtn: "Analisar Agora",
    history: "Histórico de Insights",
    placeholder: "Qual bloqueio mental ou desafio estratégico você enfrenta hoje?",
    fastMode: "Resposta Rápida",
    deepMode: "Reflexão Profunda",
    listenBtn: "Ouvir Voz de Suní"
  },
  en: {
    dialogue: "Dialogue",
    counselor: "Mental Coach",
    live: "Live Session",
    creative: "Creative Lab",
    timeline: "Timeline",
    evolution: "Evolution",
    ritual: "Daily Ritual",
    aura: "Suní's Aura",
    existentialTitle: "Suní Oracle",
    existentialSub: "Strategic analysis for minds seeking mastery.",
    reflectBtn: "Analyze Now",
    history: "Insight History",
    placeholder: "What mental block or strategic challenge are you facing today?",
    fastMode: "Fast Response",
    deepMode: "Deep Reflection",
    listenBtn: "Listen to Suní"
  },
  es: {
    dialogue: "Diálogo",
    counselor: "Coach Mental",
    live: "Sesión Viva",
    creative: "Laboratorio",
    timeline: "Línea de Tiempo",
    evolution: "Evolución",
    ritual: "Ritual Diario",
    aura: "Aura de Suní",
    existentialTitle: "El Oráculo Suní",
    existentialSub: "Análisis estratégico para mentes que buscan maestría.",
    reflectBtn: "Analizar Ahora",
    history: "Historial de Insights",
    placeholder: "¿Qué bloqueo mental o desafío estratégico enfrentas hoy?",
    fastMode: "Respuesta Rápida",
    deepMode: "Reflexión Profunda",
    listenBtn: "Escuchar a Suní"
  }
};

export const INITIAL_STATS = {
  clareza: 65,
  foco: 40,
  disciplina: 55,
  energia: 70,
  bemEstar: 60,
  coragem: 45
};

export const INITIAL_EVENTS = [
  {
    id: '1',
    year: 2024,
    month: 'Março',
    title: 'Despertar de Suní',
    description: 'A jornada para a alta consciência e performance começou.',
    emotion: 'positive' as const
  }
];
