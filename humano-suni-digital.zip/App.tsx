
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar.tsx';
import Chat from './components/Chat.tsx';
import Dashboard from './components/Dashboard.tsx';
import Timeline from './components/Timeline.tsx';
import Ritual from './components/Ritual.tsx';
import CreativeLab from './components/CreativeLab.tsx';
import LiveSession from './components/LiveSession.tsx';
import ExistentialCounselor from './components/ExistentialCounselor.tsx';
import { AppView, Message, LifeEvent, LifeStats, Language } from './types.ts';
import { INITIAL_EVENTS, INITIAL_STATS, TRANSLATIONS } from './constants.tsx';
import { geminiService } from './services/gemini.ts';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('app_lang') as Language) || 'pt';
  });
  const [activeView, setActiveView] = useState<AppView>(AppView.CHAT);
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('chat_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [events] = useState<LifeEvent[]>(INITIAL_EVENTS);
  const [stats] = useState<LifeStats>(INITIAL_STATS);
  const [isApiHealthy, setIsApiHealthy] = useState<boolean | null>(null);

  useEffect(() => {
    localStorage.setItem('chat_history', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('app_lang', language);
  }, [language]);

  useEffect(() => {
    const checkApi = async () => {
      try {
        await geminiService.translateText("test", "en");
        setIsApiHealthy(true);
      } catch (e) {
        setIsApiHealthy(false);
      }
    };
    checkApi();
  }, []);

  const userContext = `
    PERFIL DO ATLETA DA VIDA:
    - Marco Histórico: ${events.map(e => e.title).join(', ')}
    - Bio-métricas Mentais: Clareza(${stats.clareza}), Coragem(${stats.coragem}), Foco(${stats.foco}).
    - Idioma: ${language}
  `;

  return (
    <div className="flex h-screen bg-[#0a0a0c] text-zinc-200 overflow-hidden">
      <Sidebar 
        activeView={activeView} 
        setActiveView={setActiveView} 
        language={language} 
        setLanguage={setLanguage} 
      />
      
      <main className="flex-1 h-full relative overflow-hidden flex flex-col">
        <header className="px-8 py-4 border-b border-zinc-800/50 flex justify-between items-center shrink-0">
          <h1 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.3em]">
            {TRANSLATIONS[language][activeView.toLowerCase() as keyof typeof TRANSLATIONS['pt']] || activeView}
          </h1>
          <div className="flex gap-4">
             <span className={`flex items-center gap-2 text-[10px] font-bold uppercase tracking-tight ${isApiHealthy ? 'text-blue-500' : 'text-red-500'}`}>
                <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${isApiHealthy ? 'bg-blue-500' : 'bg-red-500'}`}></span>
                {isApiHealthy ? (language === 'pt' ? 'SISTEMA ATIVO' : 'SYSTEM ACTIVE') : (language === 'pt' ? 'ERRO DE SINCRONIZAÇÃO' : 'SYNC ERROR')}
             </span>
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative">
          {activeView === AppView.CHAT && (
            <Chat 
              messages={messages} 
              setMessages={setMessages} 
              context={userContext} 
              language={language}
            />
          )}
          {activeView === AppView.DASHBOARD && <Dashboard stats={stats} />}
          {activeView === AppView.TIMELINE && <Timeline events={events} />}
          {activeView === AppView.RITUAL && <Ritual />}
          {activeView === AppView.CREATIVE && <CreativeLab />}
          {activeView === AppView.LIVE && <LiveSession />}
          {activeView === AppView.EXISTENTIAL && <ExistentialCounselor userContext={userContext} language={language} />}
          {activeView === AppView.IDENTITY && (
            <div className="p-12 overflow-y-auto h-full flex flex-col items-center justify-center space-y-12 fade-in text-center max-w-4xl mx-auto">
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-[100px] rounded-full"></div>
                <i className="fa-solid fa-atom text-blue-400 text-8xl animate-spin-slow relative z-10"></i>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-5xl font-serif font-bold text-white tracking-tight">{TRANSLATIONS[language].aura}</h3>
                <p className="text-zinc-500 text-xl font-light italic">"A sua presença não é um dado, é uma frequência."</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                <div className="p-8 bg-zinc-900/40 border border-zinc-800 rounded-3xl">
                  <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest block mb-2">Estado Atual</span>
                  <p className="text-xl font-serif text-white">Observador Atento</p>
                </div>
                <div className="p-8 bg-zinc-900/40 border border-zinc-800 rounded-3xl">
                  <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest block mb-2">Traço Dominante</span>
                  <p className="text-xl font-serif text-white">Busca por Clareza</p>
                </div>
                <div className="p-8 bg-zinc-900/40 border border-zinc-800 rounded-3xl">
                  <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest block mb-2">Conexão Digital</span>
                  <p className={`text-xl font-serif ${isApiHealthy ? 'text-blue-400' : 'text-red-400'}`}>
                    {isApiHealthy ? 'Sincronizada' : 'Interrompida'}
                  </p>
                </div>
              </div>

              {!isApiHealthy && (
                <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-left space-y-3">
                  <p className="text-sm font-bold text-red-400 uppercase tracking-tight">Nota de Sincronização:</p>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Não conseguimos estabelecer o fluxo com o Google. Verifique se a sua chave de API no AI Studio está ativa e se o projeto possui faturamento ou cotas disponíveis. A sincronização GitHub-Google requer que as Secrets estejam devidamente configuradas.
                  </p>
                </div>
              )}

              <div className="pt-12 border-t border-zinc-800/50 w-full flex flex-col items-center">
                <button 
                  onClick={() => { if(confirm('Esta ação é irreversível. Deseja retornar à Tabula Rasa?')) { localStorage.clear(); window.location.reload(); } }}
                  className="px-8 py-3 bg-zinc-900 text-zinc-500 hover:text-red-400 hover:bg-red-500/10 border border-zinc-800 transition-all rounded-full text-xs font-bold uppercase tracking-widest"
                >
                  Reiniciar Biografia Digital
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
