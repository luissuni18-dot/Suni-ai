
export enum AppView {
  CHAT = 'CHAT',
  TIMELINE = 'TIMELINE',
  DASHBOARD = 'DASHBOARD',
  IDENTITY = 'IDENTITY',
  RITUAL = 'RITUAL',
  CREATIVE = 'CREATIVE',
  LIVE = 'LIVE',
  EXISTENTIAL = 'EXISTENTIAL'
}

export type Language = 'pt' | 'en' | 'es';

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  type?: 'text' | 'image' | 'video' | 'audio';
  dataUrl?: string;
  thinking?: string;
}

export interface Reflection {
  id: string;
  prompt: string;
  answer: string;
  timestamp: number;
}

export interface LifeEvent {
  id: string;
  year: number;
  month: string;
  title: string;
  description: string;
  emotion: 'positive' | 'neutral' | 'challenging';
}

export interface LifeStats {
  clareza: number;
  foco: number;
  disciplina: number;
  energia: number;
  bemEstar: number;
  coragem: number;
}

export interface UserAura {
  mantra: string;
  level: string;
  dominantTrait: string;
}
