
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants.tsx";
import { Language } from "../types.ts";

export class GeminiService {
  constructor() {}

  // Using process.env.API_KEY directly as required by guidelines
  private getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  async streamChat(
    userInput: string, 
    userContext: string, 
    onChunk: (chunk: string) => void, 
    options: { 
      lang?: Language,
      mode?: 'pro' | 'flash' | 'lite',
      deepThinking?: boolean, 
      grounding?: 'search' | 'maps', 
      attachment?: { mimeType: string, data: string } 
    } = {}
  ) {
    const ai = this.getClient();
    const lang = options.lang || 'pt';
    
    // Model selection based on task and user preference
    let modelName = 'gemini-3-pro-preview';
    if (options.mode === 'lite') modelName = 'gemini-2.5-flash-lite-latest';
    if (options.mode === 'flash' || options.grounding === 'search') modelName = 'gemini-3-flash-preview';

    const config: any = {
      systemInstruction: `${SYSTEM_PROMPT(lang)}\n\nCONTEXTO:\n${userContext}`,
    };

    if (options.deepThinking) {
      config.thinkingConfig = { thinkingBudget: 32768 };
    }

    if (options.grounding === 'search') {
      config.tools = [{ googleSearch: {} }];
    }

    const parts: any[] = [{ text: userInput }];
    if (options.attachment) {
      parts.push({
        inlineData: {
          mimeType: options.attachment.mimeType,
          data: options.attachment.data.split(',')[1]
        }
      });
    }

    const result = await ai.models.generateContentStream({
      model: modelName,
      contents: [{ role: 'user', parts }],
      config
    });

    for await (const chunk of result) {
      onChunk(chunk.text || '');
    }
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{
        parts: [{ text: `Traduza para "${targetLanguage}". Apenas o texto traduzido: \n\n${text}` }]
      }]
    });
    return response.text || text;
  }

  async generateTTS(text: string): Promise<string> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Diga com clareza e autoridade de coach: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    // PCM data is in candidates[0].content.parts[0].inlineData.data
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
  }

  async generateImage(prompt: string, aspectRatio: string, imageSize: string): Promise<string> {
    const ai = this.getClient();
    // Use Pro for high resolution, otherwise Flash Image
    const isHighRes = imageSize === '2K' || imageSize === '4K';
    const modelName = isHighRes ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
    
    const config: any = {
      imageConfig: { 
        aspectRatio: aspectRatio as any, 
      }
    };

    if (isHighRes) {
      config.imageConfig.imageSize = imageSize;
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents: { parts: [{ text: prompt }] },
      config,
    });
    
    // Iterate through all parts to find the image part
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return '';
  }

  // Adding the missing editImage method
  async editImage(prompt: string, baseImage: string): Promise<string> {
    const ai = this.getClient();
    const [mimeInfo, base64Data] = baseImage.split(',');
    const mimeType = mimeInfo.match(/:(.*?);/)?.[1] || 'image/png';

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Data, mimeType } },
          { text: prompt }
        ]
      },
    });
    
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return '';
  }

  async generateVideo(prompt: string, aspectRatio: '16:9' | '9:16', imageBase64?: string): Promise<string> {
    const ai = this.getClient();
    const payload: any = {
      model: 'veo-3.1-fast-generate-preview',
      prompt,
      config: { numberOfVideos: 1, resolution: '720p', aspectRatio }
    };

    if (imageBase64) {
      payload.image = {
        imageBytes: imageBase64.split(',')[1],
        mimeType: 'image/png'
      };
    }

    let operation = await ai.models.generateVideos(payload);
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }
    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  }

  async transcribeAudio(base64Audio: string): Promise<string> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{
        parts: [
          { inlineData: { data: base64Audio, mimeType: 'audio/wav' } },
          { text: "Transcreva este áudio de coach." }
        ]
      }]
    });
    return response.text || '';
  }
}

export const geminiService = new GeminiService();
